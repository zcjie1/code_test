# Contribute Code

dperf welcomes your contribution.
- You must agree to put your changes under [Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0).
- Please create an issue in issue list.
- Contact Committers/Owners for further discussion if needed.
- Following dperf's coding format.
- Fork -> Clone -> Pull request.
